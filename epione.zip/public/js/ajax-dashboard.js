$(document).ready(function(){

    var url = "/dashboard";

    

});