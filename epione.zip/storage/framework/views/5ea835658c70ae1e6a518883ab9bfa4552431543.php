

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="card-columns">
        <div class="card">
            <h3 class="card-header"><?php echo e($user['name']); ?></h3>
            <img class="card-img-top" src="<?php echo e($user['avatar']); ?>" alt="Profile Image" style="">
            <ul class="list-group list-group-flush">
                <li class="list-group-item"><?php echo e($user['email']); ?></li>
            </ul>
            <div class="card-block">
                <p class="card-text">Thank you, for deciding to use our service.</p>
                <p class="card-text">However, to proceed as a Client you will need to sign in to your fitbit account to give us the
                    appropriate permissions to serve you better.</p>
                <a href="<?php echo e(route('login.fitbit')); ?>" type="button" class="btn btn-primary btn-lg">Click here to continue</a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>