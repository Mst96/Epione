

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="card-columns">

        <!-- User Profile Card  -->
        <?php echo $__env->make('cards.profile', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <!-- Heart Monitor Card -->        
        <?php echo $__env->make('cards.heartRate', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        
        <!-- Sleep Monitor Card -->
        <?php echo $__env->make('cards.sleep', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <!-- Weight Card -->
        <?php echo $__env->make('cards.weight', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <!-- Last Sync Card -->
        <?php echo $__env->make('cards.lastSync', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <!-- Settings Card -->
        <?php echo $__env->make('cards.settings', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>