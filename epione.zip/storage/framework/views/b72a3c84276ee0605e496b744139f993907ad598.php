<div class="card">
    <div class="card-block">
        <h4 class="card-title">Weight</h4>
        <hr>
        <div class="text-center">
            <i class="flaticon-dumbbell fa-4x" aria-hidden="true"></i>              
            <p class="card-text"><?php echo e($profile->user->weight); ?> <?php echo e($profile->user->weightUnit); ?></p>
        </div>
    </div>
</div>
